# QuickBite — Version 05

Milestone: Hero section and promotional banner

## Requirements
- Node.js 20+
- npm
- XAMPP/MySQL from Version 09 onward

## Start frontend
```bash
cd frontend
npm install
npm run dev
```

## Start backend (Version 02 onward)
```bash
cd backend
npm install
copy .env.example .env
npm run dev
```
Use `cp .env.example .env` on macOS/Linux.

## MySQL (Version 09 onward)
1. Start Apache and MySQL in XAMPP.
2. Open phpMyAdmin and import `database/schema.sql`.
3. Set the database values and JWT secret in `backend/.env`.
4. Restart the backend.

Frontend: http://localhost:5173  
Backend health: http://localhost:5000/api/health

## Suggested GitHub commit
`Add hero section and promotional banner`

This ZIP is a complete project snapshot. The next version adds the next small milestone.
