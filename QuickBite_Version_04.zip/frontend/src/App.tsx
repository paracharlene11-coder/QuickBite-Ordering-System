import {useState} from 'react'
import {foods} from './data'
type Page='home'|'register'|'login'
export default function App(){
 const [page,setPage]=useState<Page>('home');
 const [name,setName]=useState(''),[email,setEmail]=useState(''),[password,setPassword]=useState('');
 const [message,setMessage]=useState(''),[user,setUser]=useState<{name:string}|null>(null);
 async function submit(e:React.FormEvent<HTMLFormElement>){
  e.preventDefault();setMessage('');
  if(password.length<8){setMessage('Password must contain at least 8 characters.');return;}

  setMessage('Form validation passed. Backend authentication will be connected in a later version.');

 }
 function logout(){localStorage.removeItem('quickbite_token');setUser(null);setPage('home')}
 return <div className="app">
<div className="topbar">Fresh food, made simple · Order your favorites today</div><header className="navbar"><a className="brand" href="#home"><b>Q</b> Quick<span>Bite</span></a><nav><a href="#home">Home</a><a href="#menu">Menu</a><a href="#about">About</a></nav><div className="nav-actions"><button onClick={()=>setPage('login')}>Log in</button><button className="btn small" onClick={()=>setPage('register')}>Sign up</button></div></header>
</div>}
